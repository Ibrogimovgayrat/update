import tkinter as tk
from tkinter import PhotoImage
from PIL import Image, ImageTk
import random
import pyttsx3  # pyttsx3 kutubxonasini import qilamiz (matnni ovozga aylantirish uchun)

# pyttsx3 dvigatelini ishga tushirish va Alisa ovozini tanlash
engine = pyttsx3.init()
voices = engine.getProperty('voices')
for voice in voices:
    if "alisa" in voice.name.lower():
        engine.setProperty('voice', voice.id)
        break
engine.setProperty('rate', 150)  # Nutq tezligini sozlash (default 200)

# Asosiy oynani yaratish
root = tk.Tk()
root.title("Интерактивное изучение английского языка - Для детей / Interactive English Learning - For Kids")
root.geometry("600x700")
root.config(bg="#f0f8ff")  # Fon rangini o‘rnatish

label1 = tk.Label(root, text=" Интерактивное изучение английского языка - Для детей  ", font=("Arial", 30, "bold"), fg="darkblue", width=50, bg="#f0f8ff")
label1.pack(pady=20)

# Kategoriyalar uchun rasmlar yuklash
try:
    cat_image = Image.open("cat.png").resize((400, 300))
    cat_image = ImageTk.PhotoImage(cat_image)

    it_image = Image.open("it.jpg").resize((400, 300))
    it_image = ImageTk.PhotoImage(it_image)

    yol_image = Image.open("yol.jpg").resize((400, 300))
    yol_image = ImageTk.PhotoImage(yol_image)

    sher_image = Image.open("sher.jpg").resize((400, 300))
    sher_image = ImageTk.PhotoImage(sher_image)

    fil_image = Image.open("fil.jpg").resize((400, 300))
    fil_image = ImageTk.PhotoImage(fil_image)

    ot_image = Image.open("ot.jpg").resize((400, 300))
    ot_image = ImageTk.PhotoImage(ot_image)

    maymun_image = Image.open("maymun.jpg").resize((400, 300))
    maymun_image = ImageTk.PhotoImage(maymun_image)

    jirafa_image = Image.open("jirafa.jpg").resize((400, 300))
    jirafa_image = ImageTk.PhotoImage(jirafa_image)

    zebra_image = Image.open("zebra.jpg").resize((400, 300))
    zebra_image = ImageTk.PhotoImage(zebra_image)

    ayiq_image = Image.open("ayiq.jpg").resize((400, 300))
    ayiq_image = ImageTk.PhotoImage(ayiq_image)


############################## hayvonlar tugadi ##################################################
    

    apple_image = Image.open("apple.jpg").resize((400, 300))
    apple_image = ImageTk.PhotoImage(apple_image)

    banana_image = Image.open("banana.jpg").resize((400, 300))
    banana_image = ImageTk.PhotoImage(banana_image)

    uzum_image = Image.open("uzum.jpg").resize((400, 300))
    uzum_image = ImageTk.PhotoImage(uzum_image)

    apelsin_image = Image.open("apilsen.jpg").resize((400, 300))
    apelsin_image = ImageTk.PhotoImage(apelsin_image)

    mango_image = Image.open("mango.jpg").resize((400, 300))
    mango_image = ImageTk.PhotoImage(mango_image)

    ananas_image = Image.open("anonas.jpg").resize((400, 300))
    ananas_image = ImageTk.PhotoImage(ananas_image)

    qulupnay_image = Image.open("qulupnay.jpg").resize((400, 300))
    qulupnay_image = ImageTk.PhotoImage(qulupnay_image)

    shorva_image = Image.open("shurva.jpg").resize((400, 300))
    shorva_image = ImageTk.PhotoImage(shorva_image)

    tarvuz_image = Image.open("torvuz.jpg").resize((400, 300))
    tarvuz_image = ImageTk.PhotoImage(tarvuz_image)

    papaya_image = Image.open("papaya.jpg").resize((400, 300))
    papaya_image = ImageTk.PhotoImage(papaya_image)


############################## mevalar tugadi ##################################################
    papugay_image = Image.open("papugay.jpg").resize((400, 300))
    papugay_image = ImageTk.PhotoImage(papugay_image)

    mynah_image = Image.open("mayna.jpg").resize((400, 300))
    mynah_image = ImageTk.PhotoImage(mynah_image)

    Pigeon_image = Image.open("kabutar1.jpg").resize((400, 300))
    Pigeon_image = ImageTk.PhotoImage(Pigeon_image)

    boyqush_image = Image.open("boyqush.jpg").resize((400, 300))
    boyqush_image = ImageTk.PhotoImage(boyqush_image)

    pingvin_image = Image.open("pinvin.png").resize((400, 300))
    pingvin_image = ImageTk.PhotoImage(pingvin_image)

    tavus_qushi_image = Image.open("tustoviq.png").resize((400, 300))
    tavus_qushi_image = ImageTk.PhotoImage(tavus_qushi_image)

    oqqush_image = Image.open("oqqush.jpg").resize((400, 300))
    oqqush_image = ImageTk.PhotoImage(oqqush_image)

    karga_image = Image.open("qarga.jpg").resize((400, 300))
    karga_image = ImageTk.PhotoImage(karga_image)

    kumush_qush_image = Image.open("kumush_qush.jpg").resize((400, 300))
    kumush_qush_image = ImageTk.PhotoImage(kumush_qush_image)

    yelkan_qushi_image = Image.open("yelkan.jpeg").resize((400, 300))
    yelkan_qushi_image = ImageTk.PhotoImage(yelkan_qushi_image)

############################## mevalar tugadi ##################################################

    # Ranglar
    red_image = Image.open("red.jpg").resize((400, 300))
    red_image = ImageTk.PhotoImage(red_image)

    blue_image = Image.open("blue.jpg").resize((400, 300))
    blue_image = ImageTk.PhotoImage(blue_image)

    green_image = Image.open("green.png").resize((400, 300))
    green_image = ImageTk.PhotoImage(green_image)

    yellow_image = Image.open("yellow.jpg").resize((400, 300))
    yellow_image = ImageTk.PhotoImage(yellow_image)

    black_image = Image.open("black.jpg").resize((400, 300))
    black_image = ImageTk.PhotoImage(black_image)

    white_image = Image.open("white.jpg").resize((400, 300))
    white_image = ImageTk.PhotoImage(white_image)

    # O‘quv qurollari
    book_image = Image.open("book.png").resize((400, 300))
    book_image = ImageTk.PhotoImage(book_image)

    pen_image = Image.open("pen.png").resize((400, 300))
    pen_image = ImageTk.PhotoImage(pen_image)

    pencil_image = Image.open("pencil.png").resize((400, 300))
    pencil_image = ImageTk.PhotoImage(pencil_image)

    bag_image = Image.open("bag.png").resize((400, 300))
    bag_image = ImageTk.PhotoImage(bag_image)

    ruler_image = Image.open("ruler.jpg").resize((400, 300))
    ruler_image = ImageTk.PhotoImage(ruler_image)

    # Ovqatlar
    bread_image = Image.open("bread.jpg").resize((400, 300))
    bread_image = ImageTk.PhotoImage(bread_image)

    rice_image = Image.open("rice.jpeg").resize((400, 300))
    rice_image = ImageTk.PhotoImage(rice_image)

    meat_image = Image.open("meat.png").resize((400, 300))
    meat_image = ImageTk.PhotoImage(meat_image)

    egg_image = Image.open("egg.jpg").resize((400, 300))
    egg_image = ImageTk.PhotoImage(egg_image)

    milk_image = Image.open("milk.jpg").resize((400, 300))
    milk_image = ImageTk.PhotoImage(milk_image)








############################## ranglar tugadi ##################################################

except Exception as e:
    print(f"Rasmni yuklashda xato: {e}")

# Hayvonlar, mevalar va qushlar uchun ro‘yxatlar
animals = [
    ("Cat / Кошка ", cat_image),
    ("Dog / Собака", it_image),
    ("Tiger / Тигр", yol_image),
    ("Lion / Лев", sher_image),
    ("Elephan / Слон", fil_image),
    ("Horse / Лошад", ot_image),
    ("Monkey / Обезьяна ", maymun_image),
    ("Giraffe / Жираф", jirafa_image),
    ("Zebra / Жираф", zebra_image),
    ("Bear / Медведь", ayiq_image)
]

fruits = [
    ("Apple / Яблоко ", apple_image),
    ("Banana / Банан ", banana_image),
    ("Grape / Виноград", uzum_image),
    ("Orange / Апельсин", apelsin_image),
    ("Mango / Манго", mango_image),
    ("Pineapple / Ананас", ananas_image),
    ("Strawberry / Клубника", qulupnay_image),
    ("Soup / Суп ", shorva_image),
    ("Watermelon / Арбуз", tarvuz_image),
    ("Papaya / Папайя ", papaya_image)
]

birds = [
    ("Parrot / Попугай", papugay_image),
    ("Mynah / Майна", mynah_image),
    ("Pigeon / Голубь", Pigeon_image),
    ("Owl / Сова", boyqush_image),
    ("Penguin / Пингвин", pingvin_image),
    ("Peacock /  Павлин ", tavus_qushi_image),
    ("Swan / Лебедь", oqqush_image),
    ("Crow / Ворона", karga_image),
    ("Silver bird / Серебряная птица", kumush_qush_image),
    ("Albatross / Альбатрос", yelkan_qushi_image)
]



##########################################################################

colors = [
    ("Red / Красный", red_image),
    ("Blue / Синий", blue_image),
    ("Green / Зелёный", green_image),
    ("Yellow / Жёлтый", yellow_image),
    ("Black / Чёрный", black_image),
    ("White / Белый", white_image)
]

school_items = [
    ("Book / Книга", book_image),
    ("Pen / Ручка", pen_image),
    ("Pencil / Карандаш", pencil_image),
    ("Bag / Сумка", bag_image),
    ("Ruler / Линейка", ruler_image)
]

foods = [
    ("Bread / Хлеб", bread_image),
    ("Rice / Рис", rice_image),
    ("Meat / Мясо", meat_image),
    ("Egg / Яйцо", egg_image),
    ("Milk / Молоко", milk_image)
]









###########################################################################
# Hozirgi kategoriya va javobni kuzatib borish uchun global o‘zgaruvchilar

current_category = None
current_answer = None

# So‘zni ko‘rsatish uchun yorliq (label)
word_label = tk.Label(root, text="", font=("Arial", 30, "bold"), fg="darkblue", width=20, bg="#f0f8ff")
word_label.pack(pady=20)

# Rasmni ko‘rsatish uchun yorliq
image_label = tk.Label(root, bg="#f0f8ff")
image_label.pack(pady=20)

# Xabarlarni ko‘rsatish uchun yorliq
message_label = tk.Label(root, text="", font=("Arial", 20, "italic"), fg="green", bg="#f0f8ff")
message_label.pack(pady=20)

# So‘z va rasmni ko‘rsatish, shuningdek matnni ovozga aylantirish
def show_word_and_image(category):
    global current_category, current_answer
    if category == "Животные / Animals":
        words_images = animals
    elif category == "Фрукты / Fruits":
        words_images = fruits
    elif category == "Птицы / Birds":
        words_images = birds
    elif category == "Цвета / Colors":
        words_images = colors
    elif category == "Учебные принадлежности / School Items":
        words_images = school_items
    elif category == "Еда / Foods":
        words_images = foods
    else:
        words_images = []

    current_answer, image = random.choice(words_images)
    image_label.config(image=image)
    word_label.config(text="Что это? / What is this?")
    current_category = category
    message_label.config(text="")
    create_answer_buttons()


# Foydalanuvchining javobini tekshirish
def check_answer(user_answer):
    global current_answer, message_label
    if user_answer.lower() == current_answer.lower():
        message_label.config(text="Молодец, ты правильно ответил! Очень хорошо!", fg="green")
        engine.say("Молодец, ты правильно ответил! Очень хорошо!")
        engine.runAndWait()
        root.after(1500, lambda: show_word_and_image(current_category))
    else:
        message_label.config(text="Попробуй еще раз!", fg="red")
        engine.say("Попробуй еще раз!")
        engine.runAndWait()

# Tugmalarni o‘chirish
def clear_previous_buttons():
    for widget in frame_buttons.winfo_children():
        widget.destroy()

# Javob tugmalarini yaratish
def create_answer_buttons():
    global current_answer
    clear_previous_buttons()
    answer_options = [answer[0] for answer in animals + fruits + birds if answer[0] != current_answer]
    answer_options = random.sample(answer_options, 9)
    answer_options.append(current_answer)
    random.shuffle(answer_options)

    for i, option in enumerate(answer_options):
        answer_button = tk.Button(frame_buttons, text=option, font=("Arial", 14), bg="#90EE90", width=15, height=2,
                                  command=lambda answer=option: check_answer(answer))
        answer_button.grid(row=0, column=i, padx=5, pady=5)

# Kategoriya tugmalarini yaratish
def create_category_buttons():
    animals_button = tk.Button(root, text="Животные / Animals", font=("Arial", 14), bg="#ADD8E6", width=40, height=2,
                               command=lambda: speak_and_show_category("Животные / Animals", "Animals"))
    fruits_button = tk.Button(root, text="Фрукты / Fruits", font=("Arial", 14), bg="#ADD8E6", width=40, height=2,
                              command=lambda: speak_and_show_category("Фрукты / Fruits", "Fruits"))
    birds_button = tk.Button(root, text="Птицы / Birds", font=("Arial", 14), bg="#ADD8E6", width=40, height=2,
                             command=lambda: speak_and_show_category("Птицы / Birds", "Birds"))
    colors_button = tk.Button(root, text="Цвета / Colors", font=("Arial", 14), bg="#ADD8E6", width=40, height=2,
                              command=lambda: speak_and_show_category("Цвета / Colors", "Colors"))
    school_items_button = tk.Button(root, text="Учебные принадлежности / School Items", font=("Arial", 14), bg="#ADD8E6", width=40, height=2,
                                    command=lambda: speak_and_show_category("Учебные принадлежности / School Items", "School Items"))
    foods_button = tk.Button(root, text="Еда / Foods", font=("Arial", 14), bg="#ADD8E6", width=40, height=2,
                             command=lambda: speak_and_show_category("Еда / Foods", "Foods"))

    animals_button.pack(pady=5)
    fruits_button.pack(pady=5)
    birds_button.pack(pady=5)
    colors_button.pack(pady=5)
    school_items_button.pack(pady=5)
    foods_button.pack(pady=5)


# Dasturdan chiqish tugmasi
#exit_button = tk.Button(root, text="Выход / Exit", font=("Arial", 14), bg="#FF6347", width=20, height=2,
#                        command=root.quit)
#exit_button.pack(pady=20)

# Javob tugmalarini o‘rnatish uchun ramka
frame_buttons = tk.Frame(root, bg="#f0f8ff")
frame_buttons.pack(pady=20)



# Dastur boshlanganda ovozli ko‘rsatma
def speak_choose_category():
    engine.say("Пожалуйста, выберите категорию. Please choose a category.")
    engine.runAndWait()

root.after(500, speak_choose_category)  # 1 sekunddan keyin ovozda aytsin



def speak_and_show_category(category_label, category_key):
    engine.say(category_label)
    engine.runAndWait()
    show_word_and_image(category_label)






# Dastur oynasini boshlash
create_category_buttons()
root.mainloop()

