import tkinter as tk
from tkinter import PhotoImage, StringVar, OptionMenu
from PIL import Image, ImageTk
import pyttsx3

# pyttsx3 kutubxonasini init qilish
engine = pyttsx3.init()
engine.setProperty('rate', 150)  # Nutq tezligini sozlash

# Asosiy oynani yaratish
root = tk.Tk()
root.title("Alfavit - Hayvonlar, Mevalar, Qushlar")
root.geometry("800x900")
root.config(bg="#f0f8ff")

# Til tanlash
language = StringVar(value="English")  # Default til

# Alfavit
alphabet = [chr(i) for i in range(65, 91)]  # A-Z

# Hayvonlar - Ingliz va Rus tilida
animals_en = {
    "A": "Bear, Anaconda, Antelope",
    "B": "Fish, Five-finger, Quince",
    # ...
}
animals_ru = {
    "A": "Медведь, Анаконда, Антилопа",
    "B": "Рыба, Пять пальцев, Айва",
    # ...
}

# Mevalar - Ingliz va Rus tilida
fruits_en = {
    "A": "Apple, Apricot, Avocado",
    "B": "Banana, Blackberry, Blueberry",
    # ...
}
fruits_ru = {
    "A": "Яблоко, Абрикос, Авокадо",
    "B": "Банан, Ежевика, Голубика",
    # ...
}

# Qushlar - Ingliz va Rus tilida
birds_en = {
    "A": "Albatross, Ardeola",
    "B": "Bald eagle, Billiard",
    # ...
}
birds_ru = {
    "A": "Альбатрос, Ардеола",
    "B": "Белоголовый орлан, Бильярд",
    # ...
}

# Rasmlar
animal_images = {
    "A": "images/ayiq.jpg",
    "B": "images/baliq.png",
}
fruit_images = {
    "A": "images/apple.jpg",
    "B": "images/banana.png",
}
bird_images = {
    "A": "images/aygul.jpg",
    "B": "images/bald_eagle.jpg",
}

# Rasmlarni yuklash yordamchi funksiyasi
def load_image(path):
    try:
        img = Image.open(path)
        img = img.resize((150, 150))
        return ImageTk.PhotoImage(img)
    except:
        img = Image.open("images/default.jpg")
        img = img.resize((150, 150))
        return ImageTk.PhotoImage(img)

# Harfni bosganda - ma'lumot va rasm ko'rsatish
def show_animals_fruits_birds(letter):
    # Harfni 3 marta aytish
    for _ in range(3):
        engine.say(letter)
        engine.runAndWait()

    if language.get() == "English":
        animals_list = animals_en.get(letter, "No data available")
        fruits_list = fruits_en.get(letter, "No fruits available")
        birds_list = birds_en.get(letter, "No birds available")
    else:
        animals_list = animals_ru.get(letter, "Данные недоступны")
        fruits_list = fruits_ru.get(letter, "Нет фруктов")
        birds_list = birds_ru.get(letter, "Нет птиц")

    animal_image = load_image(animal_images.get(letter, "images/default.jpg"))
    fruit_image = load_image(fruit_images.get(letter, "images/default.jpg"))
    bird_image = load_image(bird_images.get(letter, "images/default.jpg"))

    info_label.config(
        text=f"Животные / Animals:\n{animals_list}\n\n"
             f"Фрукты  / Fruits:\n{fruits_list}\n\n"
             f"Птицы / Birds:\n{birds_list}"
    )
    animal_label.config(image=animal_image)
    animal_label.image = animal_image
    fruit_label.config(image=fruit_image)
    fruit_label.image = fruit_image
    bird_label.config(image=bird_image)
    bird_label.image = bird_image

    # Nutq chiqarish
    engine.say(animals_list + ", " + fruits_list + ", " + birds_list)
    engine.runAndWait()

# Til tanlash oynasi
def change_language(*args):
    letter = alphabet[0]  # A harfi bilan boshlang
    show_animals_fruits_birds(letter)

lang_menu = OptionMenu(root, language, "English", "Russian")
lang_menu.config(font=("Arial", 14), bg="#e6e6fa", width=10)
lang_menu.grid(row=0, column=0, columnspan=13, pady=10)

# Til tanlashni yangilash
language.trace("w", change_language)

# Alfavit tugmalarini yaratish
def create_alphabet_buttons():
    for i, letter in enumerate(alphabet):
        button = tk.Button(root, text=letter, font=("Arial", 20, "bold"), width=5, height=2, 
                           bg="#ADD8E6", activebackground="#87CEFA",
                           command=lambda letter=letter: show_animals_fruits_birds(letter))
        button.grid(row=1 + (i // 13), column=i % 13, padx=3, pady=3)  # 2 qator: 13 ta ustun

# Ma'lumotlar va rasm ko'rsatuvchi label'lar
info_label = tk.Label(root, text="", font=("Arial", 14), fg="black", bg="#f0f8ff", justify=tk.LEFT)
info_label.grid(row=3, column=0, columnspan=13, pady=10)

animal_label = tk.Label(root, bg="#f0f8ff")
animal_label.grid(row=4, column=0, columnspan=13, pady=10)

fruit_label = tk.Label(root, bg="#f0f8ff")
fruit_label.grid(row=5, column=0, columnspan=13, pady=10)

bird_label = tk.Label(root, bg="#f0f8ff")
bird_label.grid(row=6, column=0, columnspan=13, pady=10)

# Tugmalarni yaratish
create_alphabet_buttons()

# Oynani ishga tushirish
root.mainloop()
