from tkinter import * 
from tkinter import ttk
from PIL import Image, ImageTk
import subprocess
import sys

class Developer:
    def __init__(self, root):
        self.root = root
        self.root.geometry("1530x790+0+0")
        self.root.title("Обучение английскому языку дошкольников")

        img_top = Image.open(r"C:\Users\Sherali\Desktop\maktabgacha\img.png")
        img_top = img_top.resize((1520, 620), Image.Resampling.LANCZOS)
        self.photoimg_top = ImageTk.PhotoImage(img_top)

        f_lbl = Label(self.root, image=self.photoimg_top)
        f_lbl.place(x=0, y=0, width=1520, height=620)

        main_frame = Frame(root, bd=2, bg="skyblue")
        main_frame.place(x=0, y=620, width=1520, height=100)

        lbl = Label(main_frame, font=("times new roman", 20, "bold"),
                    text="Teaching English to Preschool Children \n Обучение английскому языку дошкольников", fg="red", bg="skyblue")
        lbl.place(x=0, y=10, width=700, height=60)

        btn1 = Button(main_frame, font=("times new roman", 12, "italic"), text="Interactive lessons / Интерактивные уроки",
                      bg="skyblue", command=self.open_alphabet)
        btn1.place(x=720, y=10, width=300, height=60)  

        btn2 = Button(main_frame, font=("times new roman", 12, "italic"), text="Alphabet / Алфавит",
                      bg="skyblue", command=self.open_interactive_lessons)
        btn2.place(x=1030, y=10, width=250, height=60)

        btn3 = Button(main_frame, font=("times new roman", 12, "italic"), text="fruits",
                      bg="skyblue", command=self.open_meva)
        btn3.place(x=1290, y=10, width=210, height=60)        

    # FUNKSIYALAR tashqarida yoziladi
    def open_alphabet(self):
        self.root.destroy()  # Hozirgi oynani yopadi
        subprocess.Popen([sys.executable, "index.py"])  # index.py faylini ishga tushuradi

    def open_interactive_lessons(self):
        self.root.destroy()
        subprocess.Popen([sys.executable, "index1.py"])  # index1.py faylini ishga tushuradi
    
    def open_meva(self):
        self.root.destroy()
        subprocess.Popen([sys.executable, "index2.py"])  # index2.py faylini ishga tushuradi
        
if __name__ == "__main__":
    root = Tk()
    obj = Developer(root)
    root.mainloop()
