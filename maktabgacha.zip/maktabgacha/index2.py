import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import pyttsx3
import os

# Ovoz funksiyasi
engine = pyttsx3.init()
engine.setProperty('rate', 150)

def speak(word):
    engine.say(word)
    engine.runAndWait()

# Oyna sozlamalari
root = tk.Tk()
root.title("Ingliz Tili O‘rgatuvchi Dastur")
root.geometry("800x600")
root.configure(bg="#e6f2ff")

# Rasm ko‘rsatish uchun Label
image_label = tk.Label(root, bg="#e6f2ff")
image_label.pack(pady=20)

# So‘z va rasmni ko‘rsatish funksiyasi
def show_word(word):
    speak(word)
    image_path = f"images/{word}.jpg"
    if os.path.exists(image_path):
        img = Image.open(image_path)
        img = img.resize((200, 200))
        photo = ImageTk.PhotoImage(img)
        image_label.config(image=photo)
        image_label.image = photo
    else:
        image_label.config(image='', text=f"{word} (rasm topilmadi)")

# So‘zlar ro‘yxati
words = [
    "Apple", "Ball", "Cat", "Dog", "Elephant", "Fish", "Giraffe",
    "House", "Ice", "Juice", "Kite", "Lion", "Monkey", "Nest",
    "Orange", "Pen", "Queen", "Rabbit", "Sun", "Tree", "Umbrella",
    "Van", "Watch", "Xylophone", "Yogurt", "Zebra"
]

# Tugmalar paneli
button_frame = tk.Frame(root, bg="#e6f2ff")
button_frame.pack()

# Har bir tugma uchun chiroyli joylashuv
for i, word in enumerate(words):
    btn = tk.Button(button_frame, text=word, width=10, height=2,
                    bg="#add8e6", fg="black", font=("Arial", 11, "bold"),
                    command=lambda w=word: show_word(w))
    btn.grid(row=i//5, column=i%5, padx=8, pady=8)

root.mainloop()
